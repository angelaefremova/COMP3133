Angela Efremova 101311327
![img](img/1.png)
![img](img/2.png)
![img](img/3.png)
![img](img/4.png)
![img](img/5.png)
![img](img/6.png)
![img](img/7.png)